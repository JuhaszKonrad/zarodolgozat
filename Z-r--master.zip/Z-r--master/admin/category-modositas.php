<?php include('partials/menu.php'); ?>

<div class="main-content">
    <div class="wrapper">
        <h1>Kategória Módosítása</h1>
        <br><br>

        <?php

        //ID 
        if (isset($_GET['id'])) {

            $id = $_GET['id'];

            //Query
            $sql = "SELECT * FROM kategória where id=$id";

            $er = mysqli_query($kapcs, $sql);

            $count = mysqli_num_rows($er);

            if ($count == 1) {

                //Adatok kinyerése
                $row = mysqli_fetch_assoc($er);
                $title = $row['cím'];
                $currentImage = $row['kép_név'];
                $featured = $row['kiemelt'];
                $active = $row['aktív'];


            } else {
                //Redirect
                $_SESSION['no-category-found'] = "<div class='error'>Nincs ilyen kategória!</div>";
                header('location:' . HOME_URL . 'admin/category-kezeles.php');
            }

        } else {
            //Redirect
            header('location:' . HOME_URL . 'admin/category-kezeles.php');
        }

        ?>

        <form action="" method="POST" enctype="multipart/form-data">
        <table class="tbl-30">

            <tr>
                <td>Cím: </td>
                <td>
                    <input type="text" name="title" value="<?php echo $title ?>">
                </td>
            </tr>

            <tr>
                <td>Jelenlegi Kép: </td>
                <td>

                    <?php

                    if ($currentImage != '') {
                        ?>
                        <img src="<?php echo HOME_URL;?>képek/kategória/<?php echo $currentImage?>" width="130px">
                        <?php
                    } else {
                        echo "<div class='error'>Nincs kép feltöltve!</div>";
                    }

                    ?>

                </td>
            </tr>

            <tr>
                <td>Új Kép: </td>
                <td>
                    <input type="file" name="image">
                </td>
            </tr>

            <tr>
                <td>Kiemelt: </td>
                <td>
                    <input <?php if($featured == "Igen"){echo "checked";}?> type="radio" name="featured" value="Yes">Igen

                    <input <?php if($featured == "Nem"){echo "checked";}?> type="radio" name="featured" value="No">Nem
                </td>
            </tr>

            <tr>
                <td>Aktív: </td>
                <td>
                    <input <?php if($active == "Igen"){echo "checked";}?> type="radio" name="active" value="Yes">Igen

                    <input <?php if($active == "Nem"){echo "checked";}?> type="radio" name="active" value="No">Nem
                </td>
            </tr>
            <tr>
                <td>
                    <input type="submit" value="Kategória Módosítása" class="btn-secondary">
                </td>
            </tr>
        </table>
    </form>

    <?php 
    
    if(isset($_GET))

    ?>
        
    </div>
</div>


<?php include('partials/footer.php'); ?>